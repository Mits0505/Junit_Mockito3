package business;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.mockito.ArgumentCaptor;

import data.api.TodoService;
import data.api.TodoServiceStub;

public class TodoBusinessImplMockTest {

	@Test
	public void testRetrieveTodosRelatedToSpring() {
		
		TodoService todoService = mock(TodoService.class);
		when(todoService.retrieveTodos("Mitali")).thenReturn(Arrays.asList("Learn Spring","Learn Spring MVC","Learn to Dance"));
		
		TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoService);
		
		List<String> springToDos = todoBusinessImpl.retrieveTodosRelatedToSpring("Mitali");
		
		assertEquals(2,springToDos.size());
		
		assertEquals(Arrays.asList("Learn Spring","Learn Spring MVC"),springToDos);
	}
	
	@Test
	public void testRetrieveTodosRelatedToSpring_usingBDD() {
		
		// Given.
		TodoService todoService = mock(TodoService.class);
		given(todoService.retrieveTodos("Mitali")).willReturn(Arrays.asList("Learn Spring","Learn Spring MVC","Learn to Dance"));
		
		TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoService);
		
		// When
		List<String> springToDos = todoBusinessImpl.retrieveTodosRelatedToSpring("Mitali");
		
		// Then
		assertThat(springToDos.size(),is(2));
		
		assertThat(springToDos,is(Arrays.asList("Learn Spring","Learn Spring MVC")));
	}

	
	@Test
	public void testDeleteTodosNotRelatedToSpring_usingBDD() {
		
		// Given.
		TodoService todoService = mock(TodoService.class);
		given(todoService.retrieveTodos("Mitali")).willReturn(Arrays.asList("Learn Spring","Learn Spring MVC","Learn to Dance"));
		
		TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoService);
		
		// When
		todoBusinessImpl.deleteTodosNotRelatedToSpring("Mitali");
		
		// Then
		verify(todoService).deleteTodo("Learn to Dance");
		
		verify(todoService, atLeastOnce()).deleteTodo("Learn to Dance");
		verify(todoService, atLeast(1)).deleteTodo("Learn to Dance");

		verify(todoService, times(1)).deleteTodo("Learn to Dance");

		verify(todoService, never()).deleteTodo("Learn Spring MVC");
	}	
	
	@Test
	public void testDeleteTodosNotRelatedToSpring_usingBDD_argumentCapture() {
		
		// Declare Argument Captor
		ArgumentCaptor<String> stringArgumentCaptor = ArgumentCaptor.forClass(String.class);
		
		// Given.
		TodoService todoService = mock(TodoService.class);
		given(todoService.retrieveTodos("Mitali")).willReturn(Arrays.asList("Learn Spring","Learn Spring MVC","Learn to Dance"));
		
		TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoService);
		
		// When
		todoBusinessImpl.deleteTodosNotRelatedToSpring("Mitali");
		
		// Then
		
		then(todoService).should().deleteTodo("Learn to Dance");
		then(todoService).should(never()).deleteTodo("Learn Spring MVC");
		
		then(todoService).should().deleteTodo(stringArgumentCaptor.capture());
		assertThat(stringArgumentCaptor.getValue(), is("Learn to Dance"));
	}	
	
	@Test
	public void testDeleteTodosNotRelatedToSpring_usingBDD_argumentCaptureMultipleTimes() {
		
		// Declare Argument Captor
		ArgumentCaptor<String> stringArgumentCaptor = ArgumentCaptor.forClass(String.class);
		
		// Given.
		TodoService todoService = mock(TodoService.class);
		given(todoService.retrieveTodos("Mitali")).willReturn(
				                                             Arrays.asList
				                                             ("Learn Spring","Learn Spring MVC","Learn to Dance","Learn Java"));
		
		TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoService);
		
		// When
		todoBusinessImpl.deleteTodosNotRelatedToSpring("Mitali");
		
		// Then
		
		then(todoService).should().deleteTodo("Learn to Dance");
		then(todoService).should(never()).deleteTodo("Learn Spring MVC");
		
		then(todoService).should(times(2)).deleteTodo(stringArgumentCaptor.capture());
		assertThat(stringArgumentCaptor.getAllValues().size(), is(2));
	}	
}
